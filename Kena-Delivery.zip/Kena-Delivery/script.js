const phoneNumber = "251932914639";

const menuBtn = document.getElementById("menuBtn");
const navMenu = document.getElementById("navMenu");

menuBtn.addEventListener("click", () => {
  navMenu.classList.toggle("open");
});

document.querySelectorAll("#navMenu a").forEach(link => {
  link.addEventListener("click", () => navMenu.classList.remove("open"));
});

const whatsappLink = document.getElementById("whatsappLink");
whatsappLink.href = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(
  "Hello Kena Delivery, I would like to make a delivery request."
)}`;

document.getElementById("orderForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const pickup = document.getElementById("pickup").value.trim();
  const dropoff = document.getElementById("dropoff").value.trim();
  const item = document.getElementById("item").value.trim();
  const details = document.getElementById("details").value.trim();

  const message =
`Hello Kena Delivery! 🚚

I want to make a delivery request.

Name: ${name}
Phone: ${phone}
Pickup: ${pickup}
Delivery: ${dropoff}
Item/Service: ${item}
Extra details: ${details || "None"}

Please confirm the delivery price and availability.`;

  window.open(
    `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`,
    "_blank"
  );
});

document.getElementById("year").textContent = new Date().getFullYear();
